import maniac

if __name__ == "__main__":
    maniac.run_bot()