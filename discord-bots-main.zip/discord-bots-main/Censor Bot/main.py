import censor as c

if __name__ == "__main__":
    c.run_discord_bot()