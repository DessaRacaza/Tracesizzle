LIST_OF_BAD_WORDS = [
    "heck",
    "dumb",
    "stupid",
    "meanie",
    "stinky",
    "smelly",
    "nincompoop",
    "freak",
    "freaking",
    "friggin",
    "jerk",
    "nincompoop",
    "silly billy",
    "fortnite",
    "suck",
    "sucks"
]